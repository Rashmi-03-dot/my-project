const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// ✅ MongoDB connection
mongoose.connect("mongodb://127.0.0.1:27017/servehub")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

// ✅ Routes
const userRoutes = require("./routes/userRoutes");
app.use("/api/users", userRoutes);

// Test route
app.get("/", (req, res) => {
  res.send("Backend working successfully 🚀");
});

// Start server
app.listen(5000, () => {
  console.log("Server running on port 5000");
});